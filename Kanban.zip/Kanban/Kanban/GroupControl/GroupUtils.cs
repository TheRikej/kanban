﻿namespace TaskManager.GroupControl
{
    public class GroupUtils
    {

    }
}
